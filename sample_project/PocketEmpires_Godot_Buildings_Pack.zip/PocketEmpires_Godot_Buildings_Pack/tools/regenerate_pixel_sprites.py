#!/usr/bin/env python3
"""Creates original transparent Godot-compatible HD-2D building sprites.
Original cultural concept art from ImageGen is shipped separately as visual references.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import math, random, json, shutil, zipfile, hashlib, os
from collections import Counter
ROOT=Path(__file__).resolve().parent.parent
ART=ROOT/'art'/'buildings'
CONCEPT=ROOT/'art'/'concept_references'
DATA=ROOT/'data'
PREVIEW=ROOT/'previews'
for p in (ART,CONCEPT,DATA,PREVIEW,ROOT/'scripts',ROOT/'tools'): p.mkdir(parents=True,exist_ok=True)
FACTIONS=[
 ('ottomans','Osmanlılar','Ottomans','ottoman',(174,54,52),(43,126,124),(234,191,112),(223,197,147)),
 ('byzantines','Bizanslılar','Byzantines','byzantine',(105,53,105),(164,84,71),(235,188,120),(216,190,159)),
 ('britons','Britanyalılar','Britons','british',(164,43,45),(67,83,110),(220,189,155),(204,192,173)),
 ('franks','Franklar','Franks','frankish',(44,82,165),(46,77,136),(238,194,85),(207,191,159)),
 ('mongols','Moğollar','Mongols','mongol',(52,104,145),(201,142,77),(231,199,130),(207,177,137)),
 ('teutons','Tötonlar','Teutons','teutonic',(46,48,52),(49,54,60),(235,232,213),(211,207,192)),
 ('japanese','Japonlar','Japanese','japanese',(173,43,46),(45,56,63),(234,188,127),(210,182,148)),
 ('saracens','Sarazenler','Saracens','saracen',(32,110,75),(36,130,99),(227,187,98),(227,199,153)),
 ('vikings','Vikingler','Vikings','viking',(44,78,117),(121,84,50),(214,195,144),(182,152,113)),
 ('chinese','Çinliler','Chinese','chinese',(169,47,46),(44,111,95),(237,188,70),(224,197,157)),
]
BUILDINGS=[
 ('town_center','Ana Merkez','Town Center',(5,5),5.5),
 ('house','Ev','House',(2,2),2.7),
 ('barracks','Kışla','Barracks',(4,4),3.7),
 ('archery_range','Okçuluk Alanı','Archery Range',(3,3),3.3),
 ('stable','Ahır','Stable',(4,3),3.5),
 ('blacksmith','Demirci','Blacksmith',(3,3),3.3),
 ('castle','Kale','Castle',(6,6),6.2),
 ('watch_tower','Gözetleme Kulesi','Watch Tower',(2,2),5.8),
 ('lumber_camp','Oduncu Kampı','Lumber Camp',(2,2),2.5),
 ('mining_camp','Maden Kampı','Mining Camp',(2,2),2.6),
 ('mill','Değirmen','Mill',(2,2),3.2),
 ('farm','Çiftlik','Farm',(3,3),1.0),
 ('market','Pazar','Market',(4,4),2.5),
 ('stone_wall','Taş Duvar','Stone Wall',(2,1),2.5),
]
SZ=192
SCALE=2

def tint(rgb,k):return tuple(max(0,min(255,int(t*k))) for t in rgb)
def blend(a,b,t):return tuple(int(a[i]*(1-t)+b[i]*t) for i in range(3))
def rgba(c,a=255):return tuple(c[:3])+(a,)

def P(draw,coords,fill,outline=(46,42,38),w=2):
 draw.polygon(coords,fill=fill)
 draw.line(list(coords)+[coords[0]],fill=outline,width=w,joint='curve')

def ellipse(draw,box,fill,outline=None,width=1):draw.ellipse(box,fill=fill,outline=outline,width=width)

def finial(d,x,y,gold):
 d.line((x,y,x,y-6),fill=(49,41,34),width=2)
 ellipse(d,(x-2,y-10,x+2,y-6),gold,(95,69,40))

def flag(d,x,y,color,gold,seed):
 d.line((x,y,x,y-19),fill=(60,51,38),width=2)
 P(d,[(x+1,y-18),(x+17,y-16),(x+12,y-8),(x+1,y-10)],color,outline=tint(color,.55),w=1)
 d.point((x+8,y-13),fill=gold)

def brickwork(im,maskpoly,seed,wall):
 rng=random.Random(seed)
 mask=Image.new('L',im.size,0); md=ImageDraw.Draw(mask)
 md.polygon(maskpoly,fill=255)
 lay=Image.new('RGBA',im.size,(0,0,0,0));d=ImageDraw.Draw(lay)
 for y in range(35,150,8):
  xstart=11 if (y//8)%2==0 else 18
  for x in range(xstart,185,12):
   if rng.random()<.48:
    c=tint(wall,rng.choice([.82,.92,1.12]))
    d.line((x,y,x+5,y),fill=rgba(c,180),width=1)
 lay.putalpha(Image.composite(lay.getchannel('A'),Image.new('L',im.size,0),mask))
 im.alpha_composite(lay)

def ground(im,d,rng,kind):
 ellipse(d,(18,146,178,177),(38,40,32,54))
 # individual blades of grass pebbles around base (clean transparent pixels)
 for i in range(42):
  x=rng.randint(20,175);y=rng.randint(149,176)
  if (x-97)**2/85**2+(y-161)**2/18**2>1: continue
  if rng.random()<.65:
   d.line((x,y,x-1,y-3),fill=rgba(rng.choice([(99,120,70),(121,130,72),(80,105,64)]),195),width=1)
  else: ellipse(d,(x,y,x+2,y+1),(123,105,74,180))

def door(d,x,y,scale=1):
 w=int(10*scale);h=int(17*scale)
 # rounded arch (rectangle + dark arch)
 d.rounded_rectangle((x-w//2,y-h,x+w//2,y),radius=3,fill=(55,48,40),outline=(107,78,55),width=2)
 d.line((x+w//2-3,y-3,x+w//2-3,y-7),fill=(187,148,83),width=1)

def window(d,x,y,fac,gold):
 P(d,[(x-5,y-7),(x,y-10),(x+5,y-7),(x+5,y+2),(x,y+5),(x-5,y+2)],(39,46,51),outline=tint(fac,.7),w=1)
 d.line((x,y-8,x,y+4),fill=gold,width=1)
 d.line((x-4,y-3,x+4,y-3),fill=gold,width=1)

def roof_texture(im,poly,seed,color):
 rng=random.Random(seed)
 # strokes restricted to roof polygon
 mask=Image.new('L',im.size,0);dm=ImageDraw.Draw(mask);dm.polygon(poly,fill=255)
 lyr=Image.new('RGBA',im.size);d=ImageDraw.Draw(lyr)
 for y in range(30,147,7):
  for x in range(12,184,11):
   if rng.random()<.7:
    tintv=tint(color,rng.choice([.67,.85,1.23,1.4]))
    d.line((x,y,x+4,y-2),fill=rgba(tintv,165),width=1)
 lyr.putalpha(Image.composite(lyr.getchannel('A'),Image.new('L',im.size,0),mask));im.alpha_composite(lyr)

def isometric_house(im,d,rng,sty,pal,bld,scale=1.0,shift_y=0):
 # building face; field grounded at y=160
 cx=94;by=152+shift_y
 w=int(49*scale);z=int(24*scale);wallh=int(43*scale)
 left=(cx-w,by-z);rear=(cx,by-2*z);right=(cx+w,by-z);front=(cx,by)
 LT=(left[0],left[1]-wallh); RT=(right[0],right[1]-wallh)
 BT=(rear[0],rear[1]-wallh);FT=(front[0],front[1]-wallh)
 wall=pal['wall'];roof=pal['roof']; accent=pal['accent'];gold=pal['gold']
 P(d,[LT,FT,front,left],tint(wall,.92),outline=tint(wall,.5),w=2)
 P(d,[FT,RT,right,front],tint(wall,.76),outline=tint(wall,.50),w=2)
 brickwork(im,[LT,FT,front,left],int(hashlib.md5(f'{sty}/{bld}/left'.encode()).hexdigest()[:8],16),wall)
 brickwork(im,[FT,RT,right,front],int(hashlib.md5(f'{sty}/{bld}/right'.encode()).hexdigest()[:8],16),wall)
 # small timber framing for Northern factions
 if sty in ('british','frankish','teutonic','viking'):
  for i in (-1,1):
   xa=cx+(i*int(w*.43));ya=by-int(wallh*.67)
   d.line((xa,ya,xa,by-8),fill=tint(pal['trim'],.75),width=3)
  d.line((cx-w+8,by-wallh-z+12,cx+8,by-wallh//2+5),fill=tint(pal['trim'],.7),width=2)
 # roofs, culture-specific designs
 apex=(cx,by-z-wallh-int(26*scale))
 if sty in ('ottoman','byzantine','saracen') and bld in ('town_center','castle','house','mill'):
  # domed core above crenellated ledge
  P(d,[(cx-w-5,LT[1]+7),(cx,FT[1]+10),(cx+w+4,RT[1]+7),(cx,BT[1]+4)],tint(wall,.67),outline=(61,59,50),w=2)
  r=int(29*scale);sy=apex[1]+9
  dome=tint(pal['roof'],1.02)
  ellipse(d,(cx-r,sy,cx+r,sy+int(31*scale)),dome,outline=tint(dome,.55),width=2)
  d.arc((cx-r,sy-11,cx+r,sy+35),180,350,fill=tint(gold,.8),width=2)
  finial(d,cx,sy,gold)
  d.arc((cx-r+7,sy+4,cx+r-8,sy+32),200,335,fill=tint(dome,1.35),width=2)
 else:
  # two polygon pitches, 3/4 view gable roof
  e=int(6*scale);pk=int(29*scale)
  ridgeA=(cx, BT[1]-pk);ridgeB=(cx,FT[1]-pk)
  p1=[(LT[0]-e,LT[1]+e),ridgeA,ridgeB,(FT[0],FT[1]+e)]
  p2=[ridgeA,(RT[0]+e,RT[1]+e),(FT[0],FT[1]+e),ridgeB]
  P(d,p1,tint(roof,1.07),outline=tint(roof,.55),w=2)
  P(d,p2,tint(roof,.80),outline=tint(roof,.52),w=2)
  roof_texture(im,p1,int(hashlib.md5(f'{sty}/{bld}/roof1'.encode()).hexdigest()[:8],16),roof)
  roof_texture(im,p2,int(hashlib.md5(f'{sty}/{bld}/roof2'.encode()).hexdigest()[:8],16),roof)
  if sty in ('japanese','chinese'):
   # dramatic swept-up eaves
   d.line([(LT[0]-8,LT[1]+2),(LT[0]+8,LT[1]+12),(cx,FT[1]+e+6),(RT[0]+8,RT[1])],fill=tint(roof,.5),width=4,joint='curve')
   for x in [-1,1]:
    d.line((cx+x*int(w*.7),LT[1]+2,cx+x*int(w*.8),LT[1]-6),fill=gold,width=2)
  if sty=='viking':
   # ridge carved animal horn finials
   d.arc((cx-w-8,LT[1]-8,cx-w+9,LT[1]+9),200,70,fill=gold,width=3)
   d.arc((cx+w-9,RT[1]-8,cx+w+8,RT[1]+9),110,340,fill=gold,width=3)
 # Facade doors/windows
 door(d,cx-2,int(by-2),scale=max(.8,scale*.9))
 window(d,cx-int(w*.49),by-z-wallh//3,pal['trim'],gold)
 window(d,cx+int(w*.53),by-z-wallh//3,pal['trim'],gold)
 if sty=='teutonic':
  d.line((cx-22,by-21,cx-22,by-8),fill=(37,36,34),width=3)
  d.line((cx-28,by-16,cx-16,by-16),fill=(37,36,34),width=3)
 if sty in ('ottoman','byzantine','saracen') and bld in ('town_center','castle'):
  # slender tower to each side
  for xx in (cx-w+5,cx+w-5):
   d.rectangle((xx-5,LT[1]-15,xx+5,LT[1]+23),fill=tint(wall,.9),outline=tint(wall,.5),width=2)
   ellipse(d,(xx-6,LT[1]-20,xx+6,LT[1]-10),fill=tint(roof,1.12),outline=tint(roof,.53))
   finial(d,xx,LT[1]-22,gold)
 if bld in ('town_center','castle'):
  flag(d,cx+w-3,RT[1]-8,accent,gold,seed=1)
 return (cx,by,w,z,wallh)

def yurt(im,d,rng,pal,bld,scale=1):
 cx,by=96,157
 width=int(58*scale);height=int(53*scale)
 # heavy grounded circular felt structure
 ellipse(d,(cx-width,by-30,cx+width,by+9),fill=tint(pal['wall'],.79),outline=tint(pal['trim'],.52),width=2)
 d.rectangle((cx-width+8,by-height+16,cx+width-8,by-13),fill=pal['wall'],outline=tint(pal['wall'],.66),width=2)
 ellipse(d,(cx-width,by-height-9,cx+width,by-height+35),fill=tint(pal['wall'],1.1),outline=tint(pal['roof'],.7),width=2)
 P(d,[(cx-width+9,by-height+10),(cx,by-height-28),(cx+width-9,by-height+10)],tint(pal['wall'],1.03),outline=tint(pal['roof'],.72),w=3)
 d.line((cx-width+7,by-height+12,cx+width-7,by-height+12),fill=pal['accent'],width=4)
 for xx in range(cx-width+18,cx+width-12,17):d.line((xx,by-height+11,xx,by-14),fill=pal['trim'],width=2)
 door(d,cx,by,1.0)
 ellipse(d,(cx-8,by-height-32,cx+8,by-height-22),pal['roof'],tint(pal['roof'],.6))
 if bld in ('town_center','castle','barracks'):
  flag(d,cx+width-12,by-height-5,pal['accent'],pal['gold'],0)

def pagoda(im,d,sty,pal,bld,levels=2):
 cx=95;cy=148;W=55
 # tiered roofs and timber struts
 for lvl in range(levels):
  yy=cy-lvl*30;w=W-lvl*9
  P(d,[(cx-w,yy-18),(cx,yy-32),(cx+w,yy-18),(cx,yy-2)],tint(pal['wall'],.87),outline=tint(pal['wall'],.49),w=2)
  for xx in [cx-w+10,cx,cx+w-10]:
   d.line((xx,yy-24,xx,yy-8),fill=tint(pal['accent'],.85),width=4)
  roof=tint(pal['roof'],.88 if lvl==0 else 1.05)
  P(d,[(cx-w-9,yy-22),(cx-w+3,yy-37),(cx,yy-53),(cx+w-3,yy-37),(cx+w+9,yy-22),(cx,yy-31)],roof,outline=tint(roof,.5),w=3)
  d.line([(cx-w-11,yy-23),(cx-w-3,yy-18),(cx,yy-30),(cx+w+3,yy-18),(cx+w+11,yy-23)],fill=pal['gold'],width=2)
 if levels>1: finial(d,cx,cy-(levels-1)*30-53,pal['gold'])
 door(d,cx,cy-2,1.1)
 flag(d,cx+W-3,cy-32,pal['accent'],pal['gold'],0)

def object_overlays(im,d,rng,bld,sty,pal):
 a=pal['accent'];gold=pal['gold'];wood=(104,69,43); dark=(53,43,35)
 if bld=='barracks':
  d.line((43,119,58,101),fill=dark,width=4);d.line((58,119,42,101),fill=dark,width=4)
  d.line((46,118,59,105),fill=(174,186,189),width=2);d.line((57,118,44,105),fill=(174,186,189),width=2)
 if bld=='archery_range':
  ellipse(d,(29,122,49,143),(236,222,189),(89,64,43),2);ellipse(d,(34,127,44,138),a);ellipse(d,(38,131,40,134),gold)
  d.line((44,143,47,151),fill=wood,width=3)
  for i in range(3):d.line((152+i*4,144,159+i*4,127),fill=(152,115,54),width=1)
 if bld=='stable':
  for x in [34,40,46]:d.line((x,151,x,161),fill=wood,width=2)
  d.line((29,151,54,151),fill=wood,width=2)
  d.arc((155,116,172,137),40,320,fill=gold,width=3)
 if bld=='blacksmith':
  d.rectangle((141,94,156,143),fill=(106,65,54),outline=dark,width=2)
  d.rectangle((143,92,154,105),fill=(59,53,52))
  # anvil
  d.polygon([(30,157),(54,157),(51,149),(43,149),(41,144),(27,144)],fill=(89,105,112),outline=(52,60,66))
  d.line((36,161,48,161),fill=dark,width=3)
  ellipse(d,(155,83,164,95),(152,149,148,120))
 if bld=='lumber_camp':
  for j,(xx,yy) in enumerate([(31,150),(45,153),(37,159)]):
   d.line((xx,yy,xx+23,yy-9),fill=wood,width=9)
   ellipse(d,(xx-4,yy-5,xx+3,yy+4),(173,122,67),dark,1)
 if bld=='mining_camp':
  for i in range(9):
   x=25+i*5;y=146+rng.randint(-4,9)
   P(d,[(x,y),(x+7,y-11),(x+12,y),(x+10,y+4)],rng.choice([(107,114,113),(135,127,115),(87,92,93)]),w=1)
  d.line((151,157,164,133),fill=wood,width=3);d.line((154,132,171,144),fill=(129,142,141),width=3)
 if bld=='mill':
  x,y=133,80
  d.line((x,y,x,y+65),fill=wood,width=5)
  for k in range(4):
   ang=k*math.pi/2+.2
   xe=x+math.cos(ang)*29;ye=y+math.sin(ang)*29
   d.line((x,y,xe,ye),fill=(114,79,49),width=3)
   nx=-math.sin(ang)*11;ny=math.cos(ang)*11
   P(d,[(x+math.cos(ang)*10,y+math.sin(ang)*10), (xe,ye),(xe+nx,ye+ny),(x+math.cos(ang)*10+nx*.5,y+math.sin(ang)*10+ny*.5)],(219,207,166),outline=(122,96,64),w=1)
  ellipse(d,(x-5,y-5,x+5,y+5),gold,dark,2)
 if bld=='market':
  # festival canopy across foreground
  P(d,[(20,124),(75,116),(101,132),(49,146)],pal['accent'],w=2)
  for x,y in [(20,124),(49,146),(101,132)]:d.line((x,y,x,y+24),fill=wood,width=3)
  d.line((20,124,75,116),fill=gold,width=2)
  for i in range(3):ellipse(d,(43+i*9,150,48+i*9,155),(218,176,69))
 if bld=='town_center':
  d.line((38,158,48,145),fill=gold,width=2)
  d.line((48,145,52,145),fill=gold,width=3)
 if bld=='castle':
  for x in [38,142]:
   d.rectangle((x-13,119,x+13,148),fill=tint(pal['wall'],.86),outline=tint(pal['wall'],.48),width=2)
   for off in [-10,-2,6]:d.rectangle((x+off,111,x+off+6,119),fill=tint(pal['wall'],1.15),outline=tint(pal['wall'],.5))
  flag(d,147,116,a,gold,1)

def farm(im,d,rng,sty,pal):
 # terrain diamond of tilled soil, clean alpha
 P(d,[(96,96),(171,133),(96,176),(19,138)],(114,82,51),outline=(68,61,42),w=3)
 P(d,[(96,100),(161,133),(96,169),(30,137)],(142,103,62),outline=(174,133,78),w=2)
 for lane in range(7):
  yy=112+lane*6
  P(d,[(42,yy+12),(95,yy-9),(147,yy+12),(96,yy+25)],tint((127,84,49),.82 if lane%2 else 1.08),outline=(93,67,40),w=1)
  for j in range(7):
   x=53+j*12+int(lane%2*3);y=yy+8+int((x-95)*.12)
   d.line((x,y,x,y-5),fill=(83,129,67),width=2)
   d.line((x,y-4,x+3,y-6),fill=(162,165,74),width=1)
 # small cultural fence/marker
 for x,y in [(27,139),(43,147),(155,142),(139,152)]:
  d.line((x,y,x,y-13),fill=(104,70,45),width=3)
 d.line((27,130,43,139),fill=(145,94,56),width=2)
 flag(d,147,127,pal['accent'],pal['gold'],0)

def stonewall(im,d,rng,sty,pal):
 stone=tint(pal['wall'],.86)
 P(d,[(30,127),(108,91),(162,120),(86,158)],tint(stone,1.15),outline=tint(stone,.5),w=2)
 P(d,[(30,127),(86,158),(86,179),(30,148)],stone,outline=tint(stone,.50),w=2)
 P(d,[(86,158),(162,120),(162,142),(86,179)],tint(stone,.73),outline=tint(stone,.44),w=2)
 for x,y in [(36,118),(54,110),(72,102),(90,94),(110,100),(133,111),(154,120)]:
  P(d,[(x-3,y-9),(x+7,y-13),(x+11,y-5),(x,y-1)],tint(stone,1.35),outline=tint(stone,.52),w=1)
 for x,y in [(50,139),(65,148),(88,155),(108,146),(128,137)]:
  d.line((x-7,y,x+8,y-5),fill=tint(stone,.48),width=2)
 if sty=='teutonic':
  d.line((107,143,107,132),fill=(28,30,31),width=3)
  d.line((102,137,112,137),fill=(28,30,31),width=2)

def watchtower(im,d,rng,sty,pal):
 # taller narrow watchtower no cross architecture
 cx=99;by=158;w=30;wallh=76
 left=(cx-w,by-14);right=(cx+w,by-14);front=(cx,by);back=(cx,by-28)
 lt=(left[0],left[1]-wallh);rt=(right[0],right[1]-wallh);ft=(front[0],front[1]-wallh);bt=(back[0],back[1]-wallh)
 P(d,[lt,ft,front,left],pal['wall'],outline=tint(pal['wall'],.54),w=2)
 P(d,[ft,rt,right,front],tint(pal['wall'],.76),outline=tint(pal['wall'],.46),w=2)
 for i in range(2):
  window(d,86,101+i*24,pal['trim'],pal['gold']);window(d,109,101+i*24,pal['trim'],pal['gold'])
 if sty in ('japanese','chinese'):
  pagoda(im,d,sty,pal,'watch_tower',levels=2)
 else:
  P(d,[(cx-39,80),(cx,53),(cx+39,80),(cx,96)],pal['roof'],outline=tint(pal['roof'],.55),w=3)
  for x in range(75,127,13):d.rectangle((x,78,x+9,89),fill=tint(pal['wall'],1.07),outline=tint(pal['wall'],.55))
  flag(d,128,81,pal['accent'],pal['gold'],0)
 door(d,cx,by,1.1)

def draw_building(fac,bld):
 f_id, f_tr,f_en,sty,accent,roof,gold,wall=fac
 seed=int(hashlib.md5(f'{f_id}/{bld}'.encode()).hexdigest()[:8],16)
 rng=random.Random(seed)
 im=Image.new('RGBA',(SZ,SZ),(0,0,0,0));d=ImageDraw.Draw(im)
 pal={'accent':accent,'roof':roof,'gold':gold,'wall':wall,'trim':blend(wall,accent,.43)}
 if bld=='farm':
  farm(im,d,rng,sty,pal)
 elif bld=='stone_wall':
  ground(im,d,rng,bld);stonewall(im,d,rng,sty,pal)
 elif bld=='watch_tower':
  ground(im,d,rng,bld); watchtower(im,d,rng,sty,pal)
 else:
  ground(im,d,rng,bld)
  sc={'town_center':1.10,'house':.73,'barracks':.92,'archery_range':.85,'stable':.88,'blacksmith':.8,'castle':1.12,'lumber_camp':.70,'mining_camp':.70,'mill':.80,'market':.83}.get(bld,.86)
  if sty=='mongol' and bld not in ('mining_camp','lumber_camp','mill','blacksmith'):
   yurt(im,d,rng,pal,bld,sc)
  elif sty in ('japanese','chinese') and bld in ('town_center','castle'):
   pagoda(im,d,sty,pal,bld,levels=3 if bld=='castle' else 2)
  else:
   isometric_house(im,d,rng,sty,pal,bld,sc)
  object_overlays(im,d,rng,bld,sty,pal)
 # outline appearance/ pixel edges rendered at 2x nearest
 return im.resize((SZ*SCALE,SZ*SCALE),Image.Resampling.NEAREST)

manifest={'pack':'Pocket Empires – Culturally Distinct Building Sprite Art','version':'1.0','engine':'Godot 4.x','type':'2.5D static isometric sprites; not 3D meshes','source':'original transparent procedural pixel-art variants, concept references separately generated','resolution_px':[SZ*SCALE,SZ*SCALE],'base_px':[SZ,SZ], 'anchor_normalized':[.5,.89],'factions':{},'buildings':{},'notes':['Each sprite is a single static illustration; no rotation/animation frames.', 'These are clean-alpha Godot-ready pixel-art representations distinct from the detailed concept atlases.', 'Footprints are reference dimensions only; inspect the existing game collider/navigation definitions before changing them.', 'Do not infer game costs, HP or bonuses from this manifest.']}
for b,tr,en,foot,h in BUILDINGS:
 manifest['buildings'][b]={'name_tr':tr,'name_en':en,'suggested_footprint_tiles':list(foot),'suggested_visual_height_world_units':h}
for fac in FACTIONS:
 fid,name,en,sty,accent,roof,gold,wall=fac
 fdata={'display_name_tr':name,'display_name_en':en,'architecture_style':sty,'accent_rgb':list(accent),'textures':{}}
 for b,tr,ben,foot,h in BUILDINGS:
  out=ART/fid/f'{b}.png';out.parent.mkdir(exist_ok=True,parents=True)
  img=draw_building(fac,b)
  img.save(out,optimize=True)
  fdata['textures'][b]=f'res://art/buildings/{fid}/{b}.png'
 manifest['factions'][fid]=fdata
(DATA/'building_art_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
# preview contact sheet
font_path='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
font=ImageFont.truetype(font_path,15)
fontB=ImageFont.truetype(font_path,17)
scale_prev=1 # each tile ~120px
cell_w=128;cell_h=136
sheet=Image.new('RGB',(168+cell_w*len(BUILDINGS),65+cell_h*len(FACTIONS)),(32,38,43))
d=ImageDraw.Draw(sheet)
for j,(b,tr,en,*_) in enumerate(BUILDINGS):
 x=168+j*cell_w
 d.rounded_rectangle((x+2,7,x+cell_w-3,56),radius=6,fill=(52,62,67))
 d.text((x+7,10),en[:16],font=font,fill=(247,238,221))
 d.text((x+7,31),tr[:16],font=font,fill=(175,192,196))
for i,fac in enumerate(FACTIONS):
 fid,tr,en,sty,accent,*_=fac
 y=65+i*cell_h
 d.rounded_rectangle((5,y+7,161,y+cell_h-7),radius=8,fill=(48,55,60))
 d.rectangle((12,y+20,19,y+77),fill=accent)
 d.text((26,y+21),tr,font=fontB,fill=(242,241,233))
 d.text((26,y+46),en,font=font,fill=(159,177,185))
 for j,(b,*_) in enumerate(BUILDINGS):
  x=168+j*cell_w
  d.rounded_rectangle((x+2,y+2,x+cell_w-3,y+cell_h-3),radius=5,fill=(68,77,80))
  texture=Image.open(ART/fid/f'{b}.png').convert('RGBA').resize((121,121),Image.Resampling.NEAREST)
  sheet.paste(texture,(x+4,y+7),texture)
sheet.save(PREVIEW/'ALL_FACTIONS_BUILDINGS.jpg',quality=93)
# alpha checker preview for few sprites
outp=Image.new('RGBA',(384*4,384*2),(52,62,68,255))
for i,(fid,b) in enumerate([('ottomans','town_center'),('byzantines','castle'),('mongols','house'),('japanese','barracks'),('saracens','town_center'),('vikings','stable'),('teutons','watch_tower'),('chinese','mill')]):
 t=Image.open(ART/fid/f'{b}.png').convert('RGBA')
 outp.alpha_composite(t,((i%4)*384,(i//4)*384))
outp.convert('RGB').save(PREVIEW/'SPRITES_CLOSEUP.jpg',quality=95)
# copy ImageGen reference sheets
sources=[('a_detailed_high_resolution_game_asset_sheet_con.png','multifaction_concept_sheet_A.png'),('a_high_resolution_game_asset_sheet_concept_art_s.png','multifaction_concept_sheet_B.png'),('a_wide_high_resolution_game_asset_style_referenc.png','multifaction_concept_sheet_C.png')]
for src,dst in sources:
 p=CONCEPT/src
 if p.exists():shutil.copyfile(p,CONCEPT/dst)
print('Created',len(FACTIONS)*len(BUILDINGS),'sprites', 'preview=',(PREVIEW/'ALL_FACTIONS_BUILDINGS.jpg').stat().st_size,'bytes')
