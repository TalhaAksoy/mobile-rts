#!/usr/bin/env python3
"""Verify the Godot game-ready alpha sprites and exact manifest references."""
from pathlib import Path
from PIL import Image
import json, sys
ROOT=Path(__file__).resolve().parent.parent
m=json.loads((ROOT/'data'/'building_art_manifest.json').read_text(encoding='utf-8'))
fail=[];count=0
if len(m['factions'])!=10:fail.append('Faction count is not 10')
if len(m['buildings'])!=14:fail.append('Building type count is not 14')
for faction,detail in m['factions'].items():
 if set(detail['textures'])!=set(m['buildings']):fail.append(f'Building IDs mismatch: {faction}')
 for b,respath in detail['textures'].items():
  path=ROOT/respath.removeprefix('res://')
  if not path.is_file(): fail.append(f'Missing {path}');continue
  try:
   with Image.open(path) as im:
    if im.mode!='RGBA':fail.append(f'Wrong color mode {path}: {im.mode}')
    if im.size!=(384,384):fail.append(f'Wrong dimensions {path}: {im.size}')
    ext=im.getchannel('A').getextrema()
    if ext[0]!=0 or ext[1]!=255:fail.append(f'Bad transparency range: {path}: {ext}')
    if im.getpixel((0,0))[3]!=0:fail.append(f'Nontransparent corner: {path}')
  except Exception as e:fail.append(f'Invalid PNG: {path}: {e}')
  count+=1
print(f'Checked {count} PNGs, {len(m["factions"])} factions, {len(m["buildings"])} building types')
if fail:
 for f in fail: print('FAIL',f)
 sys.exit(1)
print('PASS — alpha, dimensions, manifest paths and pack coverage')
