@tool
extends Node3D
## Optional, visuals-only static Sprite3D component.
## Do not use as a substitute for Building3D physics / occupancy / navigation.

@export var faction_id: String = "ottomans"
@export var building_id: String = "town_center"
@export var pixel_size: float = 0.012
@export var fixed_y_billboard: bool = true

func _ready() -> void:
    update_visual()

func update_visual() -> void:
    var resource_path: String = "res://art/buildings/%s/%s.png" % [faction_id, building_id]
    if not ResourceLoader.exists(resource_path):
        push_warning("Missing building sprite: " + resource_path)
        return
    var texture: Texture2D = load(resource_path) as Texture2D
    var sprite: Sprite3D = get_node_or_null("Sprite3D") as Sprite3D
    if sprite == null:
        sprite = Sprite3D.new()
        sprite.name = "Sprite3D"
        add_child(sprite)
        sprite.owner = get_tree().edited_scene_root if Engine.is_editor_hint() else null
    sprite.texture = texture
    sprite.pixel_size = pixel_size
    sprite.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    sprite.billboard = SpriteBase3D.BILLBOARD_FIXED_Y if fixed_y_billboard else SpriteBase3D.BILLBOARD_DISABLED
    # Align the nominal bottom-center pivot (0.5, 0.89) with the Node3D origin.
    sprite.position = Vector3(0, (0.89 - 0.5) * float(texture.get_height()) * pixel_size, 0)
