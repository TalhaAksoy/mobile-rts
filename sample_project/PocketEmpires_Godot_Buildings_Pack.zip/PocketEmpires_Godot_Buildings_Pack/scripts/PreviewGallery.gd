extends Control

const FACTIONS = [
    ["ottomans", "Osmanlılar"], ["byzantines", "Bizanslılar"],
    ["britons", "Britanyalılar"], ["franks", "Franklar"],
    ["mongols", "Moğollar"], ["teutons", "Tötonlar"],
    ["japanese", "Japonlar"], ["saracens", "Sarazenler"],
    ["vikings", "Vikingler"], ["chinese", "Çinliler"]
]
const BUILDINGS = [
    "town_center", "house", "barracks", "archery_range", "stable",
    "blacksmith", "castle", "watch_tower", "lumber_camp", "mining_camp",
    "mill", "farm", "market", "stone_wall"
]

func _ready() -> void:
    var backdrop := ColorRect.new()
    backdrop.color = Color("262e32")
    backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(backdrop)

    var scrolling := ScrollContainer.new()
    scrolling.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(scrolling)

    var content := VBoxContainer.new()
    content.add_theme_constant_override("separation", 20)
    scrolling.add_child(content)
    for faction in FACTIONS:
        var heading := Label.new()
        heading.text = faction[1] + "  /  " + faction[0]
        content.add_child(heading)
        var grid := GridContainer.new()
        grid.columns = 7
        content.add_child(grid)
        for building_id in BUILDINGS:
            var card := VBoxContainer.new()
            card.custom_minimum_size = Vector2(180, 210)
            grid.add_child(card)
            var picture := TextureRect.new()
            picture.custom_minimum_size = Vector2(170, 175)
            picture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
            picture.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
            picture.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
            picture.texture = load("res://art/buildings/%s/%s.png" % [faction[0], building_id])
            card.add_child(picture)
            var label := Label.new()
            label.text = building_id
            label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
            card.add_child(label)
