# Pocket Empires 3D — Godot 4 HD-2D Kingdom Buildings Art Pack

Bu paket **10 krallık × 14 bina = 140 ayrı şeffaf statik PNG** ve kültürel mimari konsept atlaslarını içerir.

## Hangi klasör ne için?

- **`art/buildings/<faction>/<building>.png`** — **oyun içinde görüntülenebilir**, 384×384 RGBA, temiz alpha kanallı, pixel art, hafif ve statik 2.5D bina görselleri. Tek görüntüdür; gerçek 3D mesh değildir.
- **`art/concept_references/`** — üç adet **ayrıntılı, AI ile çizilmiş 10 krallıklı mimari referans atlası**. Bu atlaslar sprite değil, konsept tasarımdır.
- **`art/detailed_reference_crops/`** — 110 binanın atlaslardan ayrılmış **opak, ufak detaylı referans kesitleri**. Bunlar transparan DEĞİLDİR ve minik referans karakterler veya arka plan kalıntıları içerebilir. Oyun sahnesinde doğrudan `Sprite3D` olarak kullanma; tasarımları daha sonra ayrıntılandırmak için kullan.
- **`data/building_art_manifest.json`** — `faction_id` + `building_id` eşleştirmeleri, `res://` yolları, tahmini bina kapladığı alan ve pivot önerileri.
- **`previews/ALL_FACTIONS_BUILDINGS.jpg`** — 10×14 statik PNG galerisi.
- **`previews/SPRITES_CLOSEUP.jpg`** — şeffaf bina sprite'larının koyu arka planda yakın görünümü.
- **`scenes/Preview.tscn`** — Godot 4 galeri önizlemesi (oyunun kendisi değil).
- **`scripts/BuildingSprite3D.gd`** — ayrı bir Node3D altında isteğe bağlı görsel `Sprite3D` katmanı; mevcut `Building3D` kodunu değiştirmez.
- **`AGENT_PROMPT.md`** — mevcut Godot RTS projesine entegre edecek agent için direktifler.

## Krallıklar

`ottomans`, `byzantines`, `britons`, `franks`, `mongols`, `teutons`, `japanese`, `saracens`, `vikings`, `chinese`.

Önceki **PocketEmpires_Godot_ArtPack** içindeki fraksiyon ID'leriyle uyumludur.

## Bina ID'leri

`town_center`, `house`, `barracks`, `archery_range`, `stable`, `blacksmith`, `castle`, `watch_tower`, `lumber_camp`, `mining_camp`, `mill`, `farm`, `market`, `stone_wall`.

`lumber_camp`, `mining_camp` ve `mill` önceki oyun denetiminde kodda eksik olarak raporlanmıştı. Agent mevcut projede bulunup bulunmadıklarını yeniden incelemelidir. Bunların görselini eklemek **mekaniklerini eklemekle aynı şey değildir**.

## Godot içinde başlatma

1. ZIP'i aç; tek başına galeriye bakmak istersen bu klasörde `project.godot` aç.
2. Mevcut oyunda sprite kullanmak için `art/buildings/` ve `data/building_art_manifest.json` klasörlerini proje köküne kopyala.
3. Game `Building3D` içindeki fiziksel collider, grid footprint, navigation, sahiplik, can/HP, üretim ve AI fonksiyonlarını **koru**. Görsel sprite'ı mevcut binanın altında ayrı child Node3D olarak bağla.
4. Faction ID ile bina türünü manifestten çöz; dosya yolunu mevcut res:// dizilimine göre doğrula.
5. Sprite'lar **tek açıdan hazırlanmıştır**; sabit bir RTS kamerasına bakan HD-2D impostor kullanımına uygundur. Serbest 3D kamera rotasyonu, perspektif ve tam 3D çok yönlü gölgeler için ayrıca 3D modeller gerekir.
6. Sprite dokuları nearest-neighbor kullanılmalı. Sahne ölçeğini orijinal birim/köylü sprite'larıyla karşılaştır; `suggested_footprint_tiles` yalnızca referanstır, mevcut grid değerlerinin yerine otomatik geçmemelidir.
7. `python tools/verify_pack.py` ile bütün manifest yollarını, alfa kanallarını ve envanteri doğrula.

## Kalite ve dürüstlük sınırları

Bu paketin **görsel konsept katmanı** çok daha detaylıdır; 140 ayrı şeffaf bina sprite'ı ise yüksek detaylı AI çizimlerinin birebir kırpılmış halleri değil, o mimari kimliklere göre ayrı üretilmiş **sade, temiz alpha'lı oyun içi varyantlardır**. Özellikle ev, kışla, ahır gibi tiplerin bazılarında temel geometri benzerdir. Nihai ticari sanat kalitesi için ayrı karakteristik detaylar, yıkım/inşa animasyonları, farklı yönler ve sanatçı QA gerekir.

Bu pakette aşağıdakiler **yok**:
- Gerçek 3D bina geometrisi, hazır physics collider veya nav mesh.
- Kurulum / inşa / hasar / yıkım animasyonları.
- Her bina için dört yönlü kamera açısı / rotasyon sprite'ı.
- Krallık bonusları veya oynanış maliyetleri (var olan koddan yönetilmeli).
- Motor içinde doğrulanmış mobil FPS ölçümleri.

**Bu ortamda Godot binary'si bulunmadığından gerçek Godot import/render testi yapılmamıştır**; yalnızca Python format, alfa, manifest ve bütünlük testleri yapılmıştır.
