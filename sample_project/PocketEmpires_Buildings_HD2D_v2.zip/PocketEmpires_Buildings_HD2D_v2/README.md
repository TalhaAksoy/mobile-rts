# Pocket Empires HD-2D Buildings — atlas-exact sprite extraction (v2)

**This is the newly regenerated package.** It replaces the older simplistic building sprite pack, which did not visually match the original concept atlases.

## Included

- **130** individual RGBA PNG sprites: **10 factions × 13 architecture types**.
- Source images in `art/reference/`: 2 complete 5-civilization atlases.
- `data/building_art_manifest.json`: exact factions, types, sprite dimensions, anchor recommendations and locations.
- `godot/BuildingArtCatalog.gd`: a tiny dynamic Godot 4 asset loader.
- Two checkerboard previews in `previews/` to verify backgrounds are truly transparent.
- Agent task in `AGENT_PROMPT.md`.

## Art provenance and fidelity

This time, sprites are **cropped from the real illustrated building grids** using background segmentation, *not reconstructed using procedural simplified houses*. They retain the original drawing's architecture, palettes and textures. Source cell resolution limits detail and some thin roofs, flags, tree branches or ground decorations may have segmentation artifacts. Unlike genuinely authored transparent originals, these are careful **auto-cut concept-art extracts**, not pixel-perfect production sprites; visually inspect them at intended zoom and improve affected items before shipping.

## Factions

`ottomans`, `byzantines`, `britons`, `franks`, `mongols`, `teutons`, `japanese`, `saracens`, `vikings`, `chinese`.

## Building IDs

`town_center`, `house`, `barracks`, `archery_range`, `stable`, `blacksmith`, `market`, `watch_tower`, `stone_wall`, `lumber_camp`, `mining_camp`, `mill`, `castle`.

**Not included: `farm`**. The latest reference atlas does not contain a farm illustration. Keep the game's existing farm artwork instead of silently mapping the wrong building to it. Likewise, do not force new buildings into the economy unless the game already supports them.

## Integration

1. Copy `art/buildings` into `res://assets/pocket_buildings/art/buildings/` (or adapt `BuildingArtCatalog.gd` base path).
2. Create an exact game-entity ID to manifest ID mapping. Match your real `CivData.gd` IDs and `Building3D.BuildingType`; **never assume numeric enum order**.
3. Set/replace only the building's presentation `Sprite3D`. Keep existing `StaticBody3D`/`CollisionShape3D`, nav blockers, HP/damage, construction, selection, production, ownership and rally points.
4. Use a fixed-Y billboard with the normal 3/4 camera. Adjust scale/pixel size for **each category**, not just per faction. Anchor at **bottom center** of the visual, in world space; do not reposition the physical footprint.
5. Validate near/far zoom, overlap, depth sorting, foliage intersections, selection/collision, 10 factions, save/load, unit spawn, construction and demolition.
6. Never interpret these PNGs as 3D models, animation frames or directional variations.

These assets are derived from a stylized hand-painted AI generated reference sheet; no claim of specific historical accuracy.
