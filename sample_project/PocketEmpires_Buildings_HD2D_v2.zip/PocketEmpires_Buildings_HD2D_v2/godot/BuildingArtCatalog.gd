extends RefCounted
class_name PocketBuildingArtCatalog

# Copy this file and art/buildings to res://assets/pocket_buildings/.
const BASE := "res://assets/pocket_buildings/art/buildings"

static func texture_for(faction_id: String, building_id: String) -> Texture2D:
    # Map your game's actual civ and Building3D enum IDs to manifest IDs externally.
    var path := "%s/%s/%s.png" % [BASE, faction_id, building_id]
    if not ResourceLoader.exists(path):
        push_warning("PocketBuildingArt missing texture: " + path)
        return null
    return load(path) as Texture2D
