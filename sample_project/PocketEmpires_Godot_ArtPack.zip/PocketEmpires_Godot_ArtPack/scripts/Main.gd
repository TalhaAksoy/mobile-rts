extends Control
## Standalone visual preview. The extracted stills are NOT animation frames.
var catalog: Dictionary = {}
var faction_picker: OptionButton
var row_holder: HBoxContainer
var description: Label

func _ready() -> void:
    var file := FileAccess.open("res://data/faction_art_manifest.json", FileAccess.READ)
    if file == null:
        push_error("Missing faction_art_manifest.json")
        return
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    if typeof(parsed) != TYPE_DICTIONARY:
        push_error("Invalid faction asset manifest")
        return
    catalog = parsed
    _build_ui()
    for entry in catalog.get("factions", []):
        faction_picker.add_item(str(entry.get("name_tr", entry.get("id", "Unknown"))))
    faction_picker.item_selected.connect(_show_faction)
    if faction_picker.item_count > 0:
        _show_faction(0)

func _build_ui() -> void:
    var backdrop := ColorRect.new()
    backdrop.color = Color("#232832")
    backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(backdrop)

    var layout := VBoxContainer.new()
    layout.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layout.add_theme_constant_override("separation", 20)
    add_child(layout)

    var title := Label.new()
    title.text = "Pocket Empires | Faction Art Preview"
    title.add_theme_font_size_override("font_size", 28)
    layout.add_child(title)

    faction_picker = OptionButton.new()
    faction_picker.custom_minimum_size = Vector2(380, 48)
    layout.add_child(faction_picker)

    description = Label.new()
    description.text = "Concept-derived STATIC sprites. Not animation sheets."
    description.add_theme_color_override("font_color", Color("#ffdb9d"))
    layout.add_child(description)

    var scroll := ScrollContainer.new()
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    layout.add_child(scroll)
    row_holder = HBoxContainer.new()
    row_holder.add_theme_constant_override("separation", 12)
    scroll.add_child(row_holder)

func _show_faction(index: int) -> void:
    for child in row_holder.get_children():
        child.queue_free()
    var fs: Array = catalog.get("factions", [])
    if index < 0 or index >= fs.size():
        return
    var faction: Dictionary = fs[index]
    description.text = str(faction.get("name_tr", "")) + " | static PNG pose previews, transparent backgrounds"
    var units: Dictionary = faction.get("units", {})
    for role_id in faction.get("unit_ids", []):
        var info: Dictionary = units.get(role_id, {})
        var box := VBoxContainer.new()
        box.custom_minimum_size = Vector2(206, 260)
        row_holder.add_child(box)
        var label := Label.new()
        label.text = str(info.get("display_name_tr", role_id))
        label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        box.add_child(label)
        var tex := TextureRect.new()
        tex.custom_minimum_size = Vector2(200, 205)
        tex.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
        tex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
        tex.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
        var poses: Dictionary = info.get("poses", {})
        var path: String = "res://" + str(poses.get("pose_01", ""))
        tex.texture = load(path) as Texture2D
        box.add_child(tex)
        var sub := Label.new()
        sub.text = str(info.get("display_name_en", ""))
        sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        box.add_child(sub)
