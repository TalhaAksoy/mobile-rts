# Pocket Empires – Godot 4.x Faction Art Pack

Bu paket **10 krallığın** daha önce oluşturulmuş konsept çizimlerini ve bunlardan otomatik kesilmiş **50 birimin** şeffaf PNG pozlarını içerir.

## Hızlı kullanım

1. ZIP dosyasını aç.
2. Godot 4.x ile bu klasördeki `project.godot` dosyasını aç. Basit bir **art preview** sahnesi vardır; **oyunun kendisi değildir**.
3. Var olan Pocket Empires projesine `art/units/`, `art/concept_sheets/` ve `data/faction_art_manifest.json` dosyalarını kopyala. Manifestteki yolların `res://` köküne göre korunduğundan emin ol.
4. Godot'ta örnek kullanım: `load("res://art/units/ottomans/villager/pose_01.png")`.
5. Her birime **statik** Sprite2D ekle. `texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST` ayarını kullan.
6. `AGENT_PROMPT.md` dosyasındaki yönergeleri kod agent'ına gönder.

## Kapsam

- **10 orijinal poster / referans sheet**: `art/concept_sheets/*.png`
- **10 amblem/bayrak referansı**: `art/flags/*_reference.png` (mevcut oyun bayraklarıyla farklı olabilir)
- **50 birim**: krallık başına köylü, kılıçlı, mızraklı, okçu ve özel birlik
- **Her birim için 4 şeffaf PNG** (`pose_01`, `pose_02`, `rear_reference`, `action_reference`)
- Toplam **200 konseptten kesilmiş PNG**, yani **50 adet kullanılabilir statik ana poz** ve yardımcı referans pozları
- **Krallık manifesti**: `data/faction_art_manifest.json`
- **Statik poz galeri görseli**: `art/PREVIEW_contact_sheet.jpg`
- Godot 4 örnek önizleme projesi ve doğrulama betiği

## Önemli kalite sınırlamaları

Bunlar **gerçek, animasyona hazır sprite sheet'leri değildir**. Orijinal kaynaklar posterlerdi. Sprite'lar otomatik olarak kırpıldı, arka planı yaklaşık olarak temizlendi ve saydam PNG olarak kaydedildi. Bazı karakterlerde fazla arka plan izi, kesik silah, farklı pozlar veya farklı ölçekler olabilir. `pose_01` statik görsel olarak kullanılabilir; `pose_02`, `rear_reference`, `action_reference` **aynı animasyonun ardışık kareleri olarak kullanılmamalıdır**. Bunlar animasyon sanatçısına/agent'a yön gösterecek referanslardır.

- Animasyon: yürüyüş / saldırı / ölüm kareleri **henüz yok**.
- Yön: 4 veya 8 yönde tutarlı kare seti **henüz yok**.
- Birim silahlarının tamamı için temiz maskeleme **manuel kalite kontrol ister**.
- Krallıkların gerçek mekanikleri ve birim istatistikleri **bu pakette tanımlı değil**; mevcut oyunun kuralları korunmalı.
- Başlangıçtaki fraksiyon bayrak ve arma tasarımları posterin içinde referans olarak bulunur; ayrı resmi ikon dosyaları olarak sunulmaz.

## Görsel entegrasyon önerisi

Bu paketi ilk aşamada menüde birim önizlemeleri, statik placeholder'lar ve sanat referansı için kullan. Canlı RTS animasyonları için ayrı yön ve kare dizileri üret; orijinal konseptteki tasarımları, arma ve renkleri koru. Sprite'ların yürüyüş/yön/saldırı davranışını yalnızca konum değiştirerek sahte animasyon gibi sunma.

## Basit GDScript örneği

```gdscript
var texture: Texture2D = load("res://art/units/ottomans/villager/pose_01.png")
var sprite := Sprite2D.new()
sprite.texture = texture
sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
sprite.centered = true
# Ayak hizasını entity'nin dünya koordinatına getir:
sprite.offset.y = -texture.get_height() * 0.5
add_child(sprite)
```

## Test sınırları

`python tools/verify_pack.py` ile tüm PNG'lerin mevcut olup olmadığı, saydamlığının doğru formatta olması ve manifest yolları doğrulanabilir. Ortamda Godot executable olmadığı için **Godot editor/headless import veya mobil render testi yapılmadı**. Bu testleri oyunu çalıştıran agent tamamlamalıdır.
