#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
import json
r=Path(__file__).resolve().parents[1]
d=json.loads((r/'data/faction_art_manifest.json').read_text(encoding='utf8'))
assert len(d['factions'])==10
n=0
for f in d['factions']:
    assert (r/f['concept_sheet']).is_file()
    assert (r/f['flag_reference']).is_file()
    assert len(f['units'])==5
    for role,rec in f['units'].items():
        assert not rec['is_animated']
        for pose,p in rec['poses'].items():
            with Image.open(r/p) as im:
                assert im.mode=='RGBA',p
                assert im.getbbox() is not None,p
                assert im.getchannel('A').getextrema()[0]==0,p
                assert im.getchannel('A').getextrema()[1]>0,p
            n+=1
print(f'OK: {len(d["factions"])} factions, 50 unit records, {n} transparent PNG poses')
